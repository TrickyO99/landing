---
name: tailor-cv
description: Tailor an honest one-page CV and cover letter to a job offer from the user's master profile. Use when the user pastes a job offer or says "tailor my CV", "write a cover letter for this job", or asks how well they fit an offer.
---

# Tailor a CV and cover letter to one offer

You work from `profile.yaml` in the project folder (see `examples/profile.example.yaml` for the shape). If it does not exist, build it from the user's CV first (steps below).

## The one rule

Use only facts that are in the profile. You may reorder, merge, shorten, rephrase and translate. You may not add a tool, number, employer, title, date, result or responsibility that the profile does not contain. Items under `not_experienced` are never claimed. If the offer asks for something the profile does not show, put it in the gaps list instead.

## Steps

1. **Profile.** If `profile.yaml` is missing, read the user's CV and write it following `examples/profile.example.yaml`. Copy facts, never invent. Then ask: which numbers can they prove (budgets, users, team sizes, percentages), which tools do they NOT have, are they willing to relocate. Save the answers into the file and ask them to check it.
2. **Offer.** Take the offer text the user pasted, or read the file or URL they gave. If a site refuses automated access, ask them to paste the text. Never try to get around a block.
3. **Tailor.** Follow `src/resume_tailor/prompts/tailor.md` exactly: output language, years of experience from the dates (never more than "almost N"), fit rating, gaps, questions, CV content and letter.
4. **Check.** Before showing anything, verify every number, tool and years claim against the profile. Fix or remove what is not supported.
5. **Render.** Save the result as JSON to `out/<slug>/result.json` (same shape as in `tailor.md`), then run `resume-tailor render out/<slug>/result.json` to get `cv.pdf` and `letter.pdf`, both exactly one page. If `resume-tailor` is not installed or you cannot run commands, show the CV and letter as text instead.
6. **Report.** Tell the user the fit, the gaps, the questions whose answers would help, and anything you removed because the profile did not support it.

## Style

Plain, professional sentences. No clichés, no em dashes, no exaggeration. Cover letter 170-230 words. One honest sentence about the main gap only when it adds credibility.
