# resume-tailor

Give it your CV once. For every job offer it writes a **one-page CV and a cover letter tailored to that offer**, tells you how well you fit and what is missing, and keeps a small application tracker.

The rule that makes it different: **it never invents anything.** Every number, tool and number of years in the output is checked against your own profile, and anything unsupported is flagged or removed.

![A sample tailored CV](docs/sample-cv.png)

*Sample output for a fictional person. Layout fits one A4 page automatically.*

## How it works

```text
your CV (pdf/docx/txt)          job offer (file or URL)
        |                                 |
   resume-tailor init                     |
        v                                 v
   profile.yaml  ------>  resume-tailor tailor
 (facts you verified)            |
                                 |-- Claude writes the CV text and letter, using only your facts
                                 |-- honesty check: numbers, tools, years vs your profile
                                 |-- one automatic fix round if something is unsupported
                                 v
                    out/<company>-<role>/  cv.pdf  letter.pdf  report.md
                    out/tracker.html       (sortable list of all your applications)
```

`report.md` gives the fit rating (`strong`, `good`, `mid`, `weak`), why, the **gaps** between the offer and your profile, questions whose answers would strengthen the application, and the result of the honesty check.

## Install

You need Python 3.10+, Google Chrome, Chromium or Edge (used to print PDFs), and an Anthropic API key.

```bash
git clone <this repository>
cd resume-tailor
pip install .            # add ".[docx]" to read Word files
export ANTHROPIC_API_KEY=sk-ant-...      # PowerShell: $env:ANTHROPIC_API_KEY="sk-ant-..."
```

Using the Claude Code app instead of an API key? See [Use it from Claude Code](#use-it-from-claude-code).

## Quick start

```bash
# 1. Build your profile from your existing CV. Answer the few questions, then CHECK the file.
resume-tailor init my-cv.pdf

# 2. Tailor to an offer: a text file, an HTML file, or a public URL.
resume-tailor tailor offer.txt
resume-tailor tailor https://example.com/jobs/123

# 3. Track it.
resume-tailor status Contoso-Travel-Senior-Data-Analyst applied
resume-tailor tracker            # prints the list and rebuilds out/tracker.html
```

Try the layout without an API key: `resume-tailor tailor examples/offer.example.txt --dry-run` (uses `examples/profile.example.yaml` copied to `profile.yaml`; the text is not tailored).

Other commands:

- `resume-tailor pitch offer.txt --chars 140` : three short pitches for forms with a character limit.
- `resume-tailor render out/<slug>/result.json` : re-render the PDFs after you edit a sentence in `result.json` by hand.
- `resume-tailor tailor offer.txt --lang fr` : force the output language (default: the offer's language).
- `resume-tailor tailor offer.txt --notes "stress my forecasting work"` : steer the emphasis.

## The profile (`profile.yaml`)

This is the only source of truth. See [`examples/profile.example.yaml`](examples/profile.example.yaml).

- `experience[].facts` : short, true statements, ideally with numbers (budgets, users, percentages, team sizes). The tool can rephrase and reorder them but not add to them.
- `experience[].tools` and `skills` : what you really use.
- `facts` : cross-cutting claims with numbers.
- `not_experienced` : **tools and skills you do not have.** The tool will never claim them, even when an offer asks for them. If you have the skill, leave it out of this list and add a fact that shows it.
- `preferences.relocation` : text for the CV header, for example `open to relocation`. Delete it if it is not true.
- `basics.photo` : optional image path. The photo is embedded in the CV, so no extra files are needed.

The better your facts, the better the output. Spend ten minutes on this file.

## What the honesty check does

After every generation, each sentence is compared with your profile:

| Check | Example it catches |
| --- | --- |
| Numbers | "reduced costs by 40%" when no 40 appears in your profile |
| Years of experience | "ten years" when your dates add up to five |
| Tools | "Tableau" in the CV when it is not in your profile |
| Gaps | anything listed under `not_experienced` |

Sentences that say you **lack** something ("I have not used Tableau yet") pass, so letters can be honest about gaps. If a problem is found, the model gets one automatic correction round; whatever remains is printed and written to `report.md`.

**Limits.** The check is a safety net, not a guarantee. It cannot judge whether a rephrased sentence still means what your fact meant, and it only knows a fixed list of common tools. Read every CV and letter before you send it. You are responsible for what you submit.

## Privacy

- Your files stay on your machine. The **profile text and the offer text are sent to the Anthropic API** when you run `init`, `tailor` or `pitch`. Nothing else leaves your computer. Read Anthropic's terms and privacy policy for how API data is handled.
- This repository contains no personal data. `.gitignore` excludes `profile.yaml`, `out/`, photos and CVs so you do not publish yours by accident. Check `git status` before you push a fork.
- Fetching a URL sends one plain request with an honest User-Agent. Many job boards (LinkedIn, Indeed, Welcome to the Jungle and others) refuse automated requests. When that happens the tool stops and asks you to paste the offer text into a file. It does not try to get around blocks, and you should respect each site's terms of use.

## Use it from Claude Code

If you use Claude Code, the folder [`.claude/skills/tailor-cv`](.claude/skills/tailor-cv/SKILL.md) is a skill that does the same job inside the app, without an API key. Open this folder in Claude Code and ask: "tailor my CV to this offer", pasting the text.

## Development

```bash
pip install -e ".[dev]"
pytest
```

The tests cover the honesty check, rendering, the tracker and the tailoring loop with a fake model. They do not call the Anthropic API, so the first real run on your machine is the real test: read the output carefully.

Project layout: `src/resume_tailor/` (`profile`, `jobs`, `llm`, `tailor`, `guardrails`, `render`, `tracker`, `cli`), prompts in `prompts/`, HTML templates in `templates/`.

## License

MIT. See [LICENSE](LICENSE).
