import datetime as dt
from pathlib import Path

import pytest

from resume_tailor.profile import load_profile

ROOT = Path(__file__).resolve().parents[1]
TODAY = dt.date(2026, 11, 11)


@pytest.fixture
def profile():
    return load_profile(ROOT / "examples" / "profile.example.yaml")


@pytest.fixture
def offer_text():
    return (ROOT / "examples" / "offer.example.txt").read_text(encoding="utf-8")


@pytest.fixture
def today():
    return TODAY


def good_result():
    return {
        "company": "Contoso Travel",
        "job_title": "Senior Data Analyst",
        "language": "en",
        "fit": "good",
        "fit_reasons": ["SQL, Python and A/B testing are covered"],
        "gaps": ["Tableau", "GA4"],
        "questions_for_user": [],
        "cv": {
            "headline": "Data Analyst, marketing performance",
            "summary": "Data analyst with **five** years in retail analytics and marketing performance.",
            "highlight": {"label": "Experimentation", "text": "Ran 15 A/B tests on promotions"},
            "skills": [{"label": "Analytics", "text": "SQL · Python · A/B testing"}],
            "experience": [
                {"index": 0, "bullets": [
                    "Built Power BI dashboards used by 40 stakeholders",
                    "Automated the weekly sales report with Python, saving about 6 hours a week",
                ]},
                {"index": 1, "bullets": ["Cut the cost per lead by 18% by reallocating budget between channels"]},
            ],
            "earlier": [{"index": 2, "line": "Cleaned and documented 3 customer datasets"}],
        },
        "letter": {
            "subject": "Application: Senior Data Analyst",
            "greeting": "Dear Contoso Travel team,",
            "paragraphs": [
                "Your team of 12 analysts decides where each euro goes, and that is the work I enjoy.",
                "I built Power BI dashboards used by 40 stakeholders and I ran 15 A/B tests on promotions.",
                "I have not used Tableau yet, and I would learn it quickly.",
            ],
            "recipient_lines": ["Contoso Travel", "Marketing Performance", "Springfield"],
        },
    }
