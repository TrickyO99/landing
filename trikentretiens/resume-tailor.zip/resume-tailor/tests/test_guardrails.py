import copy

from conftest import good_result
from resume_tailor.guardrails import verify


def test_honest_result_passes(profile, offer_text, today):
    assert verify(good_result(), profile, offer_text, today) == []


def test_invented_number_is_flagged(profile, offer_text, today):
    r = good_result()
    r["cv"]["experience"][0]["bullets"][0] = "Built Power BI dashboards used by 400 stakeholders"
    problems = verify(r, profile, offer_text, today)
    assert any("'400'" in p for p in problems)


def test_too_many_years_is_flagged(profile, offer_text, today):
    r = good_result()
    r["letter"]["paragraphs"].append("I have ten years of experience in marketing analytics.")
    problems = verify(r, profile, offer_text, today)
    assert any("10 years" in p for p in problems)


def test_years_within_profile_are_allowed(profile, offer_text, today):
    r = good_result()
    r["letter"]["paragraphs"].append("I have five years of experience in analytics.")
    assert verify(r, profile, offer_text, today) == []


def test_tool_not_in_profile_is_flagged(profile, offer_text, today):
    r = copy.deepcopy(good_result())
    r["cv"]["skills"][0]["text"] = "SQL · Python · Looker"
    problems = verify(r, profile, offer_text, today)
    assert any("Looker" in p for p in problems)


def test_not_experienced_item_is_flagged_unless_negated(profile, offer_text, today):
    r = copy.deepcopy(good_result())
    r["letter"]["paragraphs"].append("I build dashboards in Tableau every day.")
    assert any("Tableau" in p for p in verify(r, profile, offer_text, today))
    r2 = copy.deepcopy(good_result())  # the honest sentence "I have not used Tableau yet" passes
    assert verify(r2, profile, offer_text, today) == []


def test_employer_numbers_allowed_only_when_not_first_person(profile, offer_text, today):
    offer = offer_text + "\nYou will work with 14 data engineers."
    r = good_result()
    r["letter"]["paragraphs"].append("Your 14 data engineers need a clear reporting layer.")
    assert verify(r, profile, offer, today) == []
    r["letter"]["paragraphs"].append("I managed 14 data engineers.")
    assert any("'14'" in p for p in verify(r, profile, offer, today))
