import json
import shutil

import pytest

from conftest import ROOT, good_result
from resume_tailor.cli import main
from resume_tailor.render import find_browser

needs_browser = pytest.mark.skipif(not find_browser(), reason="no Chrome/Chromium/Edge available")


@needs_browser
def test_dry_run_then_render_then_status(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    shutil.copy(ROOT / "examples" / "profile.example.yaml", tmp_path / "profile.yaml")
    offer = str(ROOT / "examples" / "offer.example.txt")

    assert main(["tailor", offer, "--dry-run"]) == 0
    folder = tmp_path / "out" / "Example-Company-Example-Role"
    assert (folder / "cv.pdf").exists() and (folder / "letter.pdf").exists() and (folder / "report.md").exists()

    # edit the result by hand, then re-render
    result = json.loads((folder / "result.json").read_text(encoding="utf-8"))
    result.update(good_result())
    (folder / "result.json").write_text(json.dumps(result), encoding="utf-8")
    assert main(["render", str(folder / "result.json")]) == 0
    assert "1 page" in capsys.readouterr().out

    assert main(["status", "Example-Company-Example-Role", "applied"]) == 0
    assert main(["tracker"]) == 0
    assert (tmp_path / "out" / "tracker.html").exists()


def test_tailor_without_api_key_fails_clearly(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    shutil.copy(ROOT / "examples" / "profile.example.yaml", tmp_path / "profile.yaml")
    if not find_browser():
        pytest.skip("no browser")
    rc = main(["tailor", str(ROOT / "examples" / "offer.example.txt")])
    assert rc == 1
    assert "ANTHROPIC_API_KEY" in capsys.readouterr().err
