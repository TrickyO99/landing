import json
from pathlib import Path

import pytest

from conftest import good_result
from resume_tailor import tracker
from resume_tailor.jobs import detect_language, html_to_text, slugify
from resume_tailor.llm import FakeLLM, parse_json
from resume_tailor.profile import total_years, validate
from resume_tailor.render import (build_cv, cv_context, find_browser, format_month, letter_context, period,
                                  _env)
from resume_tailor.tailor import dry_run_result, normalize, tailor


def test_example_profile_is_valid(profile):
    assert validate(profile) == []


def test_total_years(profile, today):
    assert 5.5 < total_years(profile, today) < 5.9


def test_parse_json_handles_fences():
    assert parse_json('```json\n{"a": 1}\n```') == {"a": 1}
    with pytest.raises(ValueError):
        parse_json("no json here")


def test_html_to_text_and_helpers():
    text = html_to_text("<div><h1>Role</h1><ul><li>SQL</li><li>Python</li></ul><script>x()</script></div>")
    assert "Role" in text and "- SQL" in text and "x()" not in text
    assert detect_language("Nous recherchons un candidat pour notre équipe, vous aurez une mission") == "fr"
    assert detect_language("We are looking for an analyst to join our team") == "en"
    assert slugify("Contoso Travel: Senior Data Analyst!") == "Contoso-Travel-Senior-Data-Analyst"


def test_month_formatting():
    assert format_month("2023-04", "en") == "Apr. 2023"
    assert format_month("2023-04", "fr") == "Avr. 2023"
    assert period({"start": "2023-04", "end": "present"}, "en") == "Apr. 2023 – Present"


def test_normalize_drops_bad_indexes(profile):
    r = good_result()
    r["cv"]["experience"].append({"index": 99, "bullets": ["x"]})
    r["cv"]["earlier"].append({"index": 0, "line": "duplicate of a shown role"})
    out = normalize(r, profile)
    assert [e["index"] for e in out["cv"]["experience"]] == [0, 1]
    assert [e["index"] for e in out["cv"]["earlier"]] == [2]


def test_tailor_runs_a_fix_round(profile, offer_text, today):
    bad = good_result()
    bad["cv"]["summary"] = "Analyst with ten years of experience."
    answers = [bad, good_result()]
    llm = FakeLLM(lambda system, user: answers.pop(0))
    result = tailor(profile, offer_text, llm, "en", today=today)
    assert len(llm.calls) == 2
    assert result["warnings"] == []
    assert "problems:" in llm.calls[1][1]


def test_templates_render(profile):
    r = normalize(good_result(), profile)
    html = _env.get_template("cv.html.j2").render(**cv_context(profile, r, "en", 0, None))
    assert "Alex" in html and "Built Power BI dashboards" in html and "<b>five</b>" in html
    letter = _env.get_template("letter.html.j2").render(**letter_context(profile, r, "en", 0))
    assert "Dear Contoso Travel team" in letter


def test_dry_run_and_pdf(profile, offer_text, tmp_path):
    result = dry_run_result(profile, offer_text, "en")
    assert result["cv"]["experience"]
    if not find_browser():
        pytest.skip("no Chrome/Chromium/Edge available")
    info = build_cv(profile, result, tmp_path, "en")
    assert info["pages"] == 1 and Path(info["pdf"]).exists()


def test_tracker(tmp_path):
    tracker.upsert(tmp_path, {"slug": "a", "company": "A", "role": "R", "fit": "good"})
    tracker.upsert(tmp_path, {"slug": "a", "company": "A", "role": "R", "fit": "strong"})
    assert len(tracker.load(tmp_path)) == 1
    entry = tracker.set_status(tmp_path, "a", "applied")
    assert entry["status"] == "applied" and entry["applied_at"]
    page = tracker.build_html(tmp_path)
    assert "Application tracker" in page.read_text(encoding="utf-8")
    with pytest.raises(KeyError):
        tracker.set_status(tmp_path, "missing", "applied")
    assert json.loads((tmp_path / "tracker.json").read_text(encoding="utf-8"))[0]["fit"] == "strong"
