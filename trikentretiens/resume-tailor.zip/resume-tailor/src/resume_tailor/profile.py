"""The master profile: the single source of truth about the candidate.

Everything a tailored CV or letter may claim must come from this file.
"""
from __future__ import annotations

import datetime as dt
import re
from pathlib import Path
from typing import Any

import yaml

# Keys whose content must NOT count as things the candidate has done.
NEGATIVE_KEYS = {"not_experienced"}
# Keys that are bookkeeping, not claims.
IGNORED_KEYS = {"photo", "notes"}


def load_profile(path: str | Path) -> dict:
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path} is not a valid profile (expected a YAML mapping).")
    return data


def save_profile(profile: dict, path: str | Path) -> None:
    Path(path).write_text(
        yaml.safe_dump(profile, allow_unicode=True, sort_keys=False, width=100),
        encoding="utf-8",
    )


def validate(profile: dict) -> list[str]:
    """Return a list of human-readable problems (empty if the profile is usable)."""
    problems: list[str] = []
    basics = profile.get("basics") or {}
    for key in ("name", "email"):
        if not basics.get(key):
            problems.append(f"basics.{key} is missing")
    exps = profile.get("experience") or []
    if not exps:
        problems.append("experience is empty")
    for i, e in enumerate(exps):
        for key in ("company", "title", "start"):
            if not e.get(key):
                problems.append(f"experience[{i}].{key} is missing")
        if not (e.get("facts") or []):
            problems.append(f"experience[{i}] ({e.get('company', '?')}) has no facts: the tool can only use what you list")
    return problems


def parse_month(value: Any, today: dt.date | None = None) -> dt.date | None:
    """Parse 'YYYY-MM', 'YYYY' or 'present' into a date (first day of the month)."""
    today = today or dt.date.today()
    if value in (None, "", "present", "Present", "now", "current"):
        return today
    s = str(value).strip()
    m = re.fullmatch(r"(\d{4})(?:-(\d{1,2}))?", s)
    if not m:
        return None
    return dt.date(int(m.group(1)), int(m.group(2) or 1), 1)


def total_years(profile: dict, today: dt.date | None = None) -> float:
    """Years between the earliest start and the latest end/today (internships included)."""
    today = today or dt.date.today()
    starts, ends = [], []
    for e in profile.get("experience") or []:
        s = parse_month(e.get("start"), today)
        if s:
            starts.append(s)
            ends.append(parse_month(e.get("end"), today) or today)
    if not starts:
        return 0.0
    return round((max(ends) - min(starts)).days / 365.25, 1)


def flatten_strings(node: Any, skip_keys: set[str] | None = None) -> list[str]:
    skip = (skip_keys or set()) | NEGATIVE_KEYS | IGNORED_KEYS
    out: list[str] = []
    if isinstance(node, dict):
        for k, v in node.items():
            if k in skip:
                continue
            out.extend(flatten_strings(v, skip_keys))
    elif isinstance(node, (list, tuple)):
        for v in node:
            out.extend(flatten_strings(v, skip_keys))
    elif node is not None:
        out.append(str(node))
    return out


def claim_text(profile: dict) -> str:
    """All text the candidate asserts is true (excludes the 'not_experienced' list)."""
    return "\n".join(flatten_strings(profile))


def initials(name: str) -> str:
    parts = [p for p in re.split(r"\s+", name.strip()) if p]
    return "".join(p[0].upper() for p in parts[:2]) or "?"
