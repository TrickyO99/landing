"""Thin wrapper around the Anthropic API that returns parsed JSON."""
from __future__ import annotations

import json
import os
import re
from typing import Callable, Protocol

DEFAULT_MODEL = "claude-sonnet-5-5"


class LLM(Protocol):
    def json(self, system: str, user: str, max_tokens: int = 6000) -> dict: ...


def parse_json(text: str) -> dict:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I)
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError(f"The model did not return JSON: {text[:200]!r}")
    return json.loads(text[start:end + 1])


class AnthropicLLM:
    def __init__(self, model: str | None = None):
        if not os.environ.get("ANTHROPIC_API_KEY"):
            raise RuntimeError(
                "ANTHROPIC_API_KEY is not set. Create a key at https://console.anthropic.com, "
                "then export it (or put it in your shell profile). Use --dry-run to try the tool without a key."
            )
        import anthropic  # imported lazily so tests and --dry-run work without the key

        self.client = anthropic.Anthropic()
        self.model = model or os.environ.get("RESUME_TAILOR_MODEL", DEFAULT_MODEL)

    def json(self, system: str, user: str, max_tokens: int = 6000) -> dict:
        last_error: Exception | None = None
        prompt = user
        for _ in range(2):
            msg = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": prompt}],
            )
            text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
            try:
                return parse_json(text)
            except ValueError as e:
                last_error = e
                prompt = user + "\n\nYour previous answer was not valid JSON. Return one JSON object and nothing else."
        raise RuntimeError(f"Could not get valid JSON from the model: {last_error}")


class FakeLLM:
    """Deterministic stand-in used by tests."""

    def __init__(self, fn: Callable[[str, str], dict]):
        self.fn = fn
        self.calls: list[tuple[str, str]] = []

    def json(self, system: str, user: str, max_tokens: int = 6000) -> dict:
        self.calls.append((system, user))
        return self.fn(system, user)
