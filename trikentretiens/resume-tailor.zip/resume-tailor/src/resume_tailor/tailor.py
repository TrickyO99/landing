"""The tailoring step: profile + offer in, CV content + letter + honesty report out."""
from __future__ import annotations

import datetime as dt
import json
from importlib import resources

import yaml

from .guardrails import verify
from .jobs import detect_language
from .llm import LLM
from .profile import total_years


def load_prompt(name: str) -> str:
    return resources.files("resume_tailor").joinpath("prompts", name).read_text(encoding="utf-8")


def profile_for_prompt(profile: dict, today: dt.date | None = None) -> str:
    p = {k: v for k, v in profile.items() if k != "questions"}
    basics = dict(p.get("basics") or {})
    basics.pop("photo", None)
    p["basics"] = basics
    p["computed"] = {"total_years": total_years(profile, today)}
    return yaml.safe_dump(p, allow_unicode=True, sort_keys=False, width=120)


def build_user_prompt(profile: dict, offer_text: str, language: str, notes: str = "",
                      today: dt.date | None = None) -> str:
    parts = [
        f"language: {language}",
        "",
        "# Candidate profile (the only source of facts)",
        profile_for_prompt(profile, today),
        "",
        "# Job offer",
        offer_text.strip()[:12000],
    ]
    if notes:
        parts += ["", "# Extra instructions from the candidate", notes]
    return "\n".join(parts)


def normalize(result: dict, profile: dict) -> dict:
    """Make the model output safe for the renderer."""
    n_exp = len(profile.get("experience") or [])
    result.setdefault("company", "Company")
    result.setdefault("job_title", "Role")
    result.setdefault("fit", "mid")
    if result["fit"] not in {"strong", "good", "mid", "weak"}:
        result["fit"] = "mid"
    for key in ("fit_reasons", "gaps", "questions_for_user", "warnings"):
        result[key] = [str(x) for x in (result.get(key) or [])]
    cv = result.setdefault("cv", {})
    cv.setdefault("headline", "")
    cv.setdefault("summary", "")
    cv["highlight"] = cv.get("highlight") or {}
    cv["skills"] = [s for s in (cv.get("skills") or []) if isinstance(s, dict)][:4]
    seen: set[int] = set()
    exps = []
    for e in cv.get("experience") or []:
        idx = e.get("index")
        if isinstance(idx, int) and 0 <= idx < n_exp and idx not in seen:
            seen.add(idx)
            exps.append({"index": idx, "bullets": [str(b) for b in (e.get("bullets") or [])][:5]})
    if not exps:
        for i in range(min(3, n_exp)):
            seen.add(i)
            facts = (profile["experience"][i].get("facts") or [])[:3]
            exps.append({"index": i, "bullets": [str(f) for f in facts]})
    cv["experience"] = exps
    cv["earlier"] = [
        {"index": e["index"], "line": str(e.get("line", ""))}
        for e in (cv.get("earlier") or [])
        if isinstance(e.get("index"), int) and 0 <= e["index"] < n_exp and e["index"] not in seen
    ]
    letter = result.setdefault("letter", {})
    letter["paragraphs"] = [str(p) for p in (letter.get("paragraphs") or [])]
    letter.setdefault("subject", "")
    letter.setdefault("greeting", "")
    letter["recipient_lines"] = [str(x) for x in (letter.get("recipient_lines") or []) if x]
    return result


def tailor(profile: dict, offer_text: str, llm: LLM, language: str | None = None, notes: str = "",
           max_fix_rounds: int = 1, today: dt.date | None = None) -> dict:
    language = language or detect_language(offer_text)
    system = load_prompt("tailor.md")
    user = build_user_prompt(profile, offer_text, language, notes, today)
    result = llm.json(system, user, max_tokens=6000)
    problems = verify(result, profile, offer_text, today)
    rounds = 0
    while problems and rounds < max_fix_rounds:
        fix_user = (
            "problems:\n" + "\n".join(f"- {p}" for p in problems)
            + "\n\nprevious_output:\n" + json.dumps(result, ensure_ascii=False)
            + "\n\nprofile:\n" + profile_for_prompt(profile, today)
        )
        result = llm.json(load_prompt("fix.md"), fix_user, max_tokens=6000)
        problems = verify(result, profile, offer_text, today)
        rounds += 1
    result["language"] = result.get("language") or language
    result["warnings"] = problems
    return normalize(result, profile)


def dry_run_result(profile: dict, offer_text: str, language: str | None = None) -> dict:
    """A no-API result built straight from the profile. Useful to try the layout."""
    language = language or detect_language(offer_text)
    exps = profile.get("experience") or []
    basics = profile.get("basics") or {}
    skills = [
        {"label": g.get("name", ""), "text": " · ".join(g.get("items") or [])}
        for g in (profile.get("skills") or [])[:4]
    ]
    result = {
        "company": "Example Company",
        "job_title": "Example Role",
        "language": language,
        "fit": "mid",
        "fit_reasons": ["Dry run: no analysis was performed."],
        "gaps": [],
        "questions_for_user": [],
        "cv": {
            "headline": basics.get("headline") or (exps[0].get("title") if exps else ""),
            "summary": profile.get("summary") or "",
            "highlight": {},
            "skills": skills,
            "experience": [
                {"index": i, "bullets": (exps[i].get("facts") or [])[:3]} for i in range(min(3, len(exps)))
            ],
            "earlier": [
                {"index": i, "line": f"{exps[i].get('title', '')}, {exps[i].get('company', '')}"}
                for i in range(3, len(exps))
            ],
        },
        "letter": {
            "subject": "Application",
            "greeting": "Dear hiring team,",
            "paragraphs": [
                "[Dry run] This letter is a placeholder. Run the command without --dry-run and with "
                "ANTHROPIC_API_KEY set to get a letter tailored to the offer."
            ],
            "recipient_lines": ["Example Company"],
        },
    }
    return normalize(result, profile)


def make_pitch(profile: dict, offer_text: str, llm: LLM, max_chars: int, language: str | None = None,
               today: dt.date | None = None) -> list[str]:
    language = language or detect_language(offer_text)
    user = (
        f"language: {language}\nmax_chars: {max_chars}\n\n# Candidate profile\n"
        f"{profile_for_prompt(profile, today)}\n\n# Job offer\n{offer_text.strip()[:8000]}"
    )
    data = llm.json(load_prompt("pitch.md"), user, max_tokens=1200)
    options = [str(o).strip() for o in (data.get("options") or []) if str(o).strip()]
    return [o for o in options if len(o) <= max_chars]
