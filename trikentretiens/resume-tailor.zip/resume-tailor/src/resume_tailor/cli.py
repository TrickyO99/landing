"""Command line interface: init, tailor, pitch, status, tracker."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__, tracker
from .guardrails import summarize
from .jobs import BlockedError, detect_language, load_offer, slugify
from .profile import load_profile, save_profile, validate
from .render import build_cv, build_letter, find_browser


def _llm(args):
    from .llm import AnthropicLLM

    return AnthropicLLM(args.model)


# ------------------------------------------------------------------ init


def _read_cv(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".txt", ".md"}:
        return path.read_text(encoding="utf-8", errors="replace")
    if suffix == ".pdf":
        from pypdf import PdfReader

        return "\n".join((page.extract_text() or "") for page in PdfReader(str(path)).pages)
    if suffix == ".docx":
        try:
            import docx
        except ImportError as e:
            raise SystemExit("Reading .docx needs: pip install 'resume-tailor[docx]'") from e
        return "\n".join(p.text for p in docx.Document(str(path)).paragraphs)
    if suffix == ".json":
        return path.read_text(encoding="utf-8")
    raise SystemExit(f"Unsupported CV format: {suffix}. Use .pdf, .docx, .txt, .md or .json (JSON Resume).")


def _ask(prompt: str) -> str:
    try:
        return input(prompt).strip()
    except EOFError:
        return ""


def cmd_init(args) -> int:
    from .tailor import load_prompt

    cv_path = Path(args.cv)
    if not cv_path.exists():
        raise SystemExit(f"CV not found: {cv_path}")
    target = Path(args.profile)
    if target.exists() and not args.force:
        raise SystemExit(f"{target} already exists. Use --force to overwrite it.")
    text = _read_cv(cv_path).strip()
    if len(text) < 200:
        raise SystemExit("Could not read enough text from that file (is it a scanned image?).")
    llm = _llm(args)  # fails early, with a clear message, if there is no API key
    print("Reading your CV with Claude... (your CV text is sent to the Anthropic API)")
    data = llm.json(load_prompt("extract_profile.md"), text[:30000], max_tokens=6000)
    questions = [str(q) for q in (data.pop("questions", None) or [])]
    data.setdefault("facts", [])
    data.setdefault("not_experienced", [])
    data.setdefault("preferences", {})
    if not args.yes:
        print("\nA few questions make the result more accurate. Press Enter to skip any of them.")
        for q in questions[:8]:
            print(f"  - {q}")
        print("\nNumbers you can prove (budget, team size, users, % results), one per line. Empty line to stop:")
        while True:
            line = _ask("  > ")
            if not line:
                break
            data["facts"].append(line)
        gaps = _ask("Tools or skills you do NOT have (comma separated), so they are never claimed: ")
        data["not_experienced"] = [g.strip() for g in gaps.split(",") if g.strip()]
        reloc = _ask("Relocation text for the CV header (e.g. 'open to relocation'), or empty: ")
        if reloc:
            data["preferences"]["relocation"] = reloc
        photo = _ask("Path to a photo (optional, png/jpg), or empty: ")
        if photo:
            data.setdefault("basics", {})["photo"] = photo
    save_profile(data, target)
    problems = validate(data)
    print(f"\nSaved {target}. Open it, check every fact, and fix anything wrong: the tool only uses what is in this file.")
    if problems:
        print("To fix:")
        for p in problems:
            print(f"  - {p}")
    return 0


# ------------------------------------------------------------------ tailor


def _report(result: dict, files: dict, slug: str) -> str:
    def bullets(items):
        return "\n".join(f"- {x}" for x in items) if items else "- none"

    return "\n".join([
        f"# {result['company']}: {result['job_title']}",
        "",
        f"**Fit:** {result['fit']}",
        "",
        "## Why", bullets(result["fit_reasons"]), "",
        "## Gaps (the offer wants these, your profile does not show them)", bullets(result["gaps"]), "",
        "## Questions that could strengthen this application", bullets(result["questions_for_user"]), "",
        "## Honesty check", summarize(result["warnings"]), "",
        "## Files", f"- CV: {files['cv']['pdf']} ({files['cv']['pages']} page)",
        f"- Letter: {files['letter']['pdf']} ({files['letter']['pages']} page)",
        f"- Tracker slug: `{slug}`",
    ])


def cmd_tailor(args) -> int:
    from .tailor import dry_run_result, tailor

    profile_path = Path(args.profile)
    if not profile_path.exists():
        raise SystemExit(f"{profile_path} not found. Run: resume-tailor init <your-cv.pdf>")
    profile = load_profile(profile_path)
    problems = validate(profile)
    if any(p.startswith("basics.name") for p in problems):
        raise SystemExit("Your profile has no name. Fix: " + "; ".join(problems))
    try:
        offer = load_offer(args.offer)
    except BlockedError as e:
        raise SystemExit(str(e))
    if len(offer["text"]) < 200:
        raise SystemExit("The offer text is too short. Paste the full posting into a text file and pass that.")
    if not find_browser():
        raise SystemExit("No Chrome, Chromium or Edge found to make PDFs. Install one or set CHROME_PATH.")
    lang = args.lang if args.lang != "auto" else detect_language(offer["text"])
    if args.dry_run:
        result = dry_run_result(profile, offer["text"], lang)
        print("Dry run: nothing was sent to any API, the text is not tailored.")
    else:
        llm = _llm(args)  # fails early, with a clear message, if there is no API key
        print("Tailoring with Claude... (your profile and the offer are sent to the Anthropic API)")
        result = tailor(profile, offer["text"], llm, lang, notes=args.notes or "")
    lang = result.get("language") or lang
    out_root = Path(args.out)
    slug = args.slug or slugify(f"{result['company']}-{result['job_title']}")
    folder = out_root / slug
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "offer.txt").write_text(offer["text"], encoding="utf-8")
    (folder / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    files = {
        "cv": build_cv(profile, result, folder, lang, profile_path.resolve().parent),
        "letter": build_letter(profile, result, folder, lang),
    }
    (folder / "report.md").write_text(_report(result, files, slug), encoding="utf-8")
    tracker.upsert(out_root, {
        "slug": slug, "company": result["company"], "role": result["job_title"],
        "location": result.get("location"), "url": offer.get("url"), "fit": result["fit"],
        "files": {"cv": f"{slug}/cv.pdf", "letter": f"{slug}/letter.pdf", "report": f"{slug}/report.md"},
    })
    tracker.build_html(out_root)

    print(f"\n{result['company']}: {result['job_title']}  ->  fit: {result['fit']}")
    print(f"  CV:     {files['cv']['pdf']}  ({files['cv']['pages']} page)")
    print(f"  Letter: {files['letter']['pdf']}  ({files['letter']['pages']} page)")
    if result["gaps"]:
        print("  Gaps:   " + "; ".join(result["gaps"]))
    if result["warnings"]:
        print("\nHonesty check found claims your profile does not support. Review them in report.md:")
        for w in result["warnings"]:
            print(f"  ! {w}")
    for key in ("cv", "letter"):
        if files[key]["pages"] > 1:
            print(f"  ! The {key} is {files[key]['pages']} pages. Shorten your profile facts or the offer-specific text.")
    return 0


# ------------------------------------------------------------------ pitch, status, tracker


def cmd_render(args) -> int:
    """Re-render the PDFs from a result.json, for example after editing it by hand."""
    from .tailor import normalize

    profile_path = Path(args.profile)
    profile = load_profile(profile_path)
    result_path = Path(args.result)
    result = normalize(json.loads(result_path.read_text(encoding="utf-8")), profile)
    folder = result_path.parent
    lang = args.lang if args.lang != "auto" else result.get("language", "en")
    cv = build_cv(profile, result, folder, lang, profile_path.resolve().parent)
    letter = build_letter(profile, result, folder, lang)
    print(f"CV:     {cv['pdf']}  ({cv['pages']} page)")
    print(f"Letter: {letter['pdf']}  ({letter['pages']} page)")
    return 0


def cmd_pitch(args) -> int:
    from .tailor import make_pitch

    profile = load_profile(args.profile)
    offer = load_offer(args.offer)
    lang = args.lang if args.lang != "auto" else detect_language(offer["text"])
    options = make_pitch(profile, offer["text"], _llm(args), args.chars, lang)
    if not options:
        print("No option fit the limit. Try again or raise --chars.")
        return 1
    for o in options:
        print(f"[{len(o)}] {o}")
    return 0


def cmd_status(args) -> int:
    entry = tracker.set_status(Path(args.out), args.slug, args.status, args.note)
    tracker.build_html(Path(args.out))
    print(f"{entry['company']}: {entry['status']}")
    return 0


def cmd_tracker(args) -> int:
    out = Path(args.out)
    path = tracker.build_html(out)
    entries = tracker.load(out)
    for e in sorted(entries, key=lambda x: (tracker.FIT_ORDER.get(x.get("fit"), 9), x["company"])):
        print(f"{e.get('fit', '?'):7} {e['status']:10} {e['company']}: {e['role']}  [{e['slug']}]")
    print(f"\nOpen {path} in your browser.")
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="resume-tailor", description=__doc__)
    p.add_argument("--version", action="version", version=__version__)
    p.add_argument("--profile", default="profile.yaml", help="path to your profile (default: profile.yaml)")
    p.add_argument("--out", default="out", help="output folder (default: out)")
    p.add_argument("--model", default=None, help="Claude model id (default: env RESUME_TAILOR_MODEL or built-in)")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init", help="build profile.yaml from your existing CV")
    s.add_argument("cv", help="your CV: .pdf, .docx, .txt, .md or JSON Resume .json")
    s.add_argument("--force", action="store_true", help="overwrite an existing profile")
    s.add_argument("--yes", action="store_true", help="skip the interactive questions")
    s.set_defaults(fn=cmd_init)

    s = sub.add_parser("tailor", help="tailor a CV and letter to one job offer")
    s.add_argument("offer", help="path to a text/html file, a URL, or - for stdin")
    s.add_argument("--lang", default="auto", help="auto (default), en, fr, ...")
    s.add_argument("--notes", default="", help="extra instructions, e.g. 'stress my data engineering work'")
    s.add_argument("--slug", default=None, help="folder name under --out")
    s.add_argument("--dry-run", action="store_true", help="no API call: render the layout from your profile only")
    s.set_defaults(fn=cmd_tailor)

    s = sub.add_parser("render", help="re-render the PDFs from an edited result.json")
    s.add_argument("result", help="path to out/<slug>/result.json")
    s.add_argument("--lang", default="auto")
    s.set_defaults(fn=cmd_render)

    s = sub.add_parser("pitch", help="short pitches for forms with a character limit")
    s.add_argument("offer")
    s.add_argument("--chars", type=int, default=140)
    s.add_argument("--lang", default="auto")
    s.set_defaults(fn=cmd_pitch)

    s = sub.add_parser("status", help="update an application's status")
    s.add_argument("slug")
    s.add_argument("status", choices=tracker.STATUSES)
    s.add_argument("--note", default=None)
    s.set_defaults(fn=cmd_status)

    s = sub.add_parser("tracker", help="list applications and rebuild tracker.html")
    s.set_defaults(fn=cmd_tracker)

    args = p.parse_args(argv)
    try:
        return args.fn(args)
    except (RuntimeError, KeyError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
