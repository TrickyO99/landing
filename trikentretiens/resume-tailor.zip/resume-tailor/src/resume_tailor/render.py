"""HTML templates to one-page PDFs (via a local Chrome, Chromium or Edge)."""
from __future__ import annotations

import base64
import datetime as dt
import mimetypes
import os
import re
import shutil
import subprocess
from pathlib import Path

from jinja2 import Environment, PackageLoader
from markupsafe import Markup, escape

from .profile import initials, parse_month

LABELS = {
    "en": dict(
        contact="Contact", phone="Phone", email="Email", location="Location", skills="Skills",
        languages="Languages", education="Education", experience="Professional experience",
        earlier="Earlier experience", present="Present", closing="Best regards,",
        months=["Jan.", "Feb.", "Mar.", "Apr.", "May", "June", "July", "Aug.", "Sept.", "Oct.", "Nov.", "Dec."],
        date_months=["January", "February", "March", "April", "May", "June", "July", "August", "September",
                     "October", "November", "December"],
    ),
    "fr": dict(
        contact="Contact", phone="Tél.", email="Email", location="Lieu", skills="Compétences",
        languages="Langues", education="Formation", experience="Expérience professionnelle",
        earlier="Expériences précédentes", present="Aujourd'hui", closing="Cordialement,",
        months=["Janv.", "Fév.", "Mars", "Avr.", "Mai", "Juin", "Juil.", "Août", "Sept.", "Oct.", "Nov.", "Déc."],
        date_months=["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre",
                     "octobre", "novembre", "décembre"],
    ),
}
DEFAULT_THEME = {"primary": "#14324a", "accent": "#1f7a8c", "light": "#9fd0dc"}
MAX_FIT_LEVEL = 3


def _emph(text: object) -> Markup:
    s = str(escape(text))
    return Markup(re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s))


_env = Environment(loader=PackageLoader("resume_tailor", "templates"), autoescape=True)
_env.filters["emph"] = _emph


def labels(lang: str) -> dict:
    return LABELS.get(lang, LABELS["en"])


def format_month(value: object, lang: str) -> str:
    L = labels(lang)
    if value in (None, "", "present", "Present", "now", "current"):
        return L["present"]
    m = re.fullmatch(r"(\d{4})(?:-(\d{1,2}))?", str(value).strip())
    if not m:
        return str(value)
    year, month = m.group(1), m.group(2)
    return f"{L['months'][int(month) - 1]} {year}" if month else year


def period(exp: dict, lang: str) -> str:
    start, end = exp.get("start"), exp.get("end")
    if not end or str(end).lower() in ("present", "now", "current"):
        return f"{format_month(start, lang)} – {labels(lang)['present']}"
    return f"{format_month(start, lang)} – {format_month(end, lang)}"


def photo_data_uri(profile: dict, base_dir: Path | None) -> str | None:
    rel = (profile.get("basics") or {}).get("photo")
    if not rel:
        return None
    path = Path(rel)
    if not path.is_absolute() and base_dir:
        path = base_dir / path
    if not path.exists():
        return None
    mime = mimetypes.guess_type(path.name)[0] or "image/png"
    return f"data:{mime};base64,{base64.b64encode(path.read_bytes()).decode()}"


def _theme(profile: dict) -> dict:
    theme = dict(DEFAULT_THEME)
    theme.update((profile.get("preferences") or {}).get("theme") or {})
    return theme


def _location_line(profile: dict) -> str:
    prefs = profile.get("preferences") or {}
    basics = profile.get("basics") or {}
    if prefs.get("location_line"):
        return str(prefs["location_line"])
    parts = [basics.get("location"), prefs.get("relocation")]
    return " · ".join(p for p in parts if p)


def _contact(profile: dict, lang: str) -> list[tuple[str, str]]:
    L = labels(lang)
    basics = profile.get("basics") or {}
    rows = []
    if basics.get("phone"):
        rows.append((L["phone"], basics["phone"]))
    if basics.get("email"):
        rows.append((L["email"], basics["email"]))
    for link in basics.get("links") or []:
        url = re.sub(r"^https?://(www\.)?", "", str(link.get("url", "")))
        rows.append((link.get("label", "Link"), url))
    loc = _location_line(profile)
    if loc:
        rows.append((L["location"], loc))
    return rows


def cv_context(profile: dict, result: dict, lang: str, fit_level: int, base_dir: Path | None) -> dict:
    basics = profile.get("basics") or {}
    exps = profile.get("experience") or []
    cv = result.get("cv") or {}
    name = basics.get("name", "")
    parts = name.split()
    first, last = (" ".join(parts[:-1]), parts[-1]) if len(parts) > 1 else (name, "")
    experience = []
    for e in cv.get("experience") or []:
        src = exps[e["index"]]
        experience.append(
            {"company": src.get("company", ""), "title": src.get("title", ""),
             "location": src.get("location", ""), "period": period(src, lang), "bullets": e["bullets"]}
        )
    earlier = []
    for e in cv.get("earlier") or []:
        src = exps[e["index"]]
        earlier.append({"period": period(src, lang), "line": e["line"]})
    return {
        "lang": lang, "L": labels(lang), "fit": fit_level, "theme": _theme(profile),
        "name": name, "first": first, "last": last, "initials": initials(name),
        "photo": photo_data_uri(profile, base_dir), "contact": _contact(profile, lang),
        "headline": cv.get("headline", ""), "summary": cv.get("summary", ""),
        "highlight": cv.get("highlight") or {}, "skills": cv.get("skills") or [],
        "languages": basics.get("languages") or [], "education": profile.get("education") or [],
        "experience": experience, "earlier": earlier,
    }


def letter_context(profile: dict, result: dict, lang: str, fit_level: int,
                   today: dt.date | None = None) -> dict:
    today = today or dt.date.today()
    L = labels(lang)
    basics = profile.get("basics") or {}
    letter = result.get("letter") or {}
    if lang == "fr":
        date = f"{today.day} {L['date_months'][today.month - 1]} {today.year}"
    else:
        date = f"{today.day} {L['date_months'][today.month - 1]} {today.year}"
    name = basics.get("name", "")
    parts = name.split()
    first, last = (" ".join(parts[:-1]), parts[-1]) if len(parts) > 1 else (name, "")
    contact = " · ".join(x for x in (basics.get("location"), basics.get("phone"), basics.get("email")) if x)
    for link in basics.get("links") or []:
        contact += " · " + re.sub(r"^https?://(www\.)?", "", str(link.get("url", "")))
    return {
        "lang": lang, "fit": fit_level, "theme": _theme(profile), "name": name, "first": first, "last": last,
        "contact": contact, "recipient": letter.get("recipient_lines") or [], "date": date,
        "subject": letter.get("subject", ""), "greeting": letter.get("greeting", ""),
        "paragraphs": letter.get("paragraphs") or [], "closing": letter.get("closing") or L["closing"],
    }


# ---------------------------------------------------------------- PDF


def find_browser() -> str | None:
    env = os.environ.get("CHROME_PATH")
    if env and Path(env).exists():
        return env
    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    ]
    for c in candidates:
        if Path(c).exists():
            return c
    for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "chrome", "msedge",
                 "microsoft-edge"):
        found = shutil.which(name)
        if found:
            return found
    return None


def html_to_pdf(html_path: Path, pdf_path: Path) -> None:
    browser = find_browser()
    if not browser:
        raise RuntimeError(
            "No Chrome, Chromium or Edge found. Install one, or set CHROME_PATH to its executable."
        )
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [browser, "--headless", "--disable-gpu", "--no-pdf-header-footer"]
    if hasattr(os, "geteuid") and os.geteuid() == 0:  # root (containers, some CI): Chrome refuses to sandbox
        cmd.append("--no-sandbox")
    cmd += [f"--print-to-pdf={pdf_path.resolve()}", html_path.resolve().as_uri()]
    subprocess.run(cmd, capture_output=True, check=False, timeout=90)
    if not pdf_path.exists():
        raise RuntimeError(f"The browser did not produce {pdf_path}.")


def count_pages(pdf_path: Path) -> int:
    try:
        from pypdf import PdfReader

        return len(PdfReader(str(pdf_path)).pages)
    except Exception:
        return len(re.findall(rb"/Type\s*/Page[^s]", pdf_path.read_bytes()))


def _render_fit(template: str, context_fn, html_path: Path, pdf_path: Path) -> dict:
    """Render with increasingly compact styles until the document is one page."""
    pages = 0
    level = 0
    for level in range(MAX_FIT_LEVEL + 1):
        html = _env.get_template(template).render(**context_fn(level))
        html_path.write_text(html, encoding="utf-8")
        html_to_pdf(html_path, pdf_path)
        pages = count_pages(pdf_path)
        if pages <= 1:
            break
    return {"pdf": str(pdf_path), "html": str(html_path), "pages": pages, "fit_level": level}


def build_cv(profile: dict, result: dict, out_dir: Path, lang: str, base_dir: Path | None = None) -> dict:
    return _render_fit("cv.html.j2", lambda lvl: cv_context(profile, result, lang, lvl, base_dir),
                       out_dir / "cv.html", out_dir / "cv.pdf")


def build_letter(profile: dict, result: dict, out_dir: Path, lang: str) -> dict:
    return _render_fit("letter.html.j2", lambda lvl: letter_context(profile, result, lang, lvl),
                       out_dir / "letter.html", out_dir / "letter.pdf")
