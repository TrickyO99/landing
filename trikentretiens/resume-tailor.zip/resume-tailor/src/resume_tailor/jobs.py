"""Reading a job offer: a text file, pasted text, or a public URL.

Fetching is deliberately polite and minimal: one plain GET, an honest User-Agent,
no cookies, no headless browser, no attempt to get around blocks. Many job boards
(LinkedIn, Indeed, Welcome to the Jungle...) refuse automated requests; when that
happens the tool asks you to paste the offer text instead.
"""
from __future__ import annotations

import html
import json
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

USER_AGENT = "resume-tailor/0.1 (personal job-search tool; single request per page)"


class BlockedError(RuntimeError):
    """The site refused an automated request."""


def _jsonld_description(raw_html: str) -> str | None:
    for m in re.finditer(r"<script[^>]*application/ld\+json[^>]*>(.*?)</script>", raw_html, re.S | re.I):
        try:
            data = json.loads(m.group(1))
        except ValueError:
            continue
        items = data if isinstance(data, list) else [data]
        for item in items:
            if isinstance(item, dict) and item.get("@type") == "JobPosting":
                parts = [item.get("title") or "", (item.get("hiringOrganization") or {}).get("name") or "",
                         item.get("description") or ""]
                return html_to_text("\n".join(p for p in parts if p))
    return None


def html_to_text(raw: str) -> str:
    raw = re.sub(r"(?is)<(script|style|nav|footer|header|svg)[^>]*>.*?</\1>", " ", raw)
    raw = re.sub(r"(?i)<br\s*/?>|</p>|</li>|</h\d>|</div>|</tr>", "\n", raw)
    raw = re.sub(r"(?i)<li[^>]*>", "- ", raw)
    raw = re.sub(r"<[^>]+>", "", raw)
    text = html.unescape(raw)
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n", text)
    return text.strip()


def fetch_url(url: str, timeout: int = 20) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept-Language": "en,fr;q=0.8"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            charset = resp.headers.get_content_charset() or "utf-8"
            body = resp.read().decode(charset, "replace")
    except urllib.error.HTTPError as e:
        if e.code in (401, 403, 429, 999):
            raise BlockedError(
                f"{url} refuses automated requests (HTTP {e.code}). "
                "Open the page yourself, copy the offer text into a file, and pass that file instead."
            ) from e
        raise
    return _jsonld_description(body) or html_to_text(body)


def load_offer(source: str) -> dict:
    """Return {'text': ..., 'url': ... or None}. ``source`` is a path, a URL, or '-' for stdin."""
    if source == "-":
        return {"text": sys.stdin.read().strip(), "url": None}
    if re.match(r"https?://", source):
        return {"text": fetch_url(source), "url": source}
    path = Path(source)
    if not path.exists():
        raise FileNotFoundError(f"Offer not found: {source}")
    raw = path.read_text(encoding="utf-8", errors="replace")
    text = html_to_text(raw) if path.suffix.lower() in {".html", ".htm"} else raw.strip()
    return {"text": text, "url": None}


_FR_WORDS = {"les", "des", "pour", "avec", "vous", "nous", "une", "dans", "sur", "est", "poste", "votre", "notre", "expérience"}
_EN_WORDS = {"the", "and", "with", "you", "we", "our", "your", "for", "will", "experience", "team", "role"}


def detect_language(text: str) -> str:
    words = re.findall(r"[a-zA-ZÀ-ÿ']+", text.lower())
    fr = sum(1 for w in words if w in _FR_WORDS)
    en = sum(1 for w in words if w in _EN_WORDS)
    return "fr" if fr > en else "en"


def slugify(value: str, max_len: int = 60) -> str:
    value = re.sub(r"[^A-Za-z0-9]+", "-", value.strip()).strip("-")
    return value[:max_len].strip("-") or "offer"
