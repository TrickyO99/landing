"""Honesty checks.

The model may rephrase, reorder and translate, but it may not invent. These
checks compare every generated sentence with the master profile and report:

* numbers that are not in the profile,
* years-of-experience claims larger than the profile supports,
* tools/skills that are not in the profile (unless the sentence says you lack them),
* anything listed under ``not_experienced`` that is claimed.
"""
from __future__ import annotations

import datetime as dt
import re
from typing import Iterable

from .profile import claim_text, total_years

NUM_RE = re.compile(r"\d+(?:[.,]\d+)?")
SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")
FIRST_PERSON = re.compile(r"\b(?:i|i've|i'm|my|me|mine|je|mon|ma|mes|moi)\b|\b[jm]['’]", re.I)
NEGATION = re.compile(
    r"\b(?:not|no|never|without|haven't|hasn't|don't|have not|yet to|pas|jamais|sans|aucun|aucune|ni)\b|\bn['’]",
    re.I,
)

# Common tools. A tool that appears in a generated text but not in the profile is flagged.
KNOWN_TOOLS = [
    "SQL", "Python", "Tableau", "Power BI", "PowerBI", "Looker", "Looker Studio", "GA4", "Google Analytics",
    "Adobe Analytics", "Mixpanel", "Amplitude", "dbt", "BigQuery", "Snowflake", "Databricks", "Redshift",
    "Spark", "Airflow", "Excel", "VBA", "Salesforce", "HubSpot", "Marketo", "Braze", "Klaviyo", "Customer.io",
    "Iterable", "Jira", "Confluence", "Figma", "Alteryx", "Dataiku", "Qlik", "Qlik Sense", "SAP", "Oracle",
    "Azure", "AWS", "GCP", "Git", "Docker", "Kubernetes", "Java", "JavaScript", "TypeScript", "React",
    "Node.js", "Scala", "MATLAB", "SAS", "Power Query", "Google Ads", "Meta Ads", "TikTok Ads",
    "Apple Search Ads", "DV360", "AppsFlyer", "Adjust", "Segment", "Hotjar", "Optimizely", "Metabase",
    "Superset", "Notion", "Zendesk", "Intercom", "Shopify", "Mongo", "PostgreSQL", "MySQL", "Hadoop",
    "TensorFlow", "PyTorch", "scikit-learn", "Pandas", "Numpy", "Kafka", "Terraform",
]
CASE_SENSITIVE_MAX_LEN = 4  # short names (SQL, SAS, AWS...) must match case to avoid false hits

_WORD_NUMBERS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
    "ten": 10, "eleven": 11, "twelve": 12, "un": 1, "deux": 2, "trois": 3, "quatre": 4, "cinq": 5,
    "sept": 7, "huit": 8, "neuf": 9, "dix": 10, "onze": 11, "douze": 12,
}
_YEARS_RE = re.compile(
    r"\b(\d+|" + "|".join(_WORD_NUMBERS) + r")\s*\+?[\s-]*(?:years?|yrs?|ans)\b", re.I
)


def _norm_number(token: str) -> str:
    token = token.replace(",", ".")
    if "." in token:
        token = token.rstrip("0").rstrip(".")
    return token


def _numbers(text: str) -> set[str]:
    return {_norm_number(t) for t in NUM_RE.findall(text)}


def _sentences(text: str) -> list[str]:
    return [s.strip() for s in SENTENCE_SPLIT.split(text) if s and s.strip()]


def _negated(sentence: str, start: int) -> bool:
    return bool(NEGATION.search(sentence[max(0, start - 80):start]))


def _tool_pattern(tool: str) -> re.Pattern:
    flags = 0 if len(tool) <= CASE_SENSITIVE_MAX_LEN else re.I
    return re.compile(r"(?<![\w])" + re.escape(tool) + r"(?![\w])", flags)


def collect_segments(result: dict) -> list[tuple[str, str]]:
    """Every generated text of a tailoring result as (location, text)."""
    segs: list[tuple[str, str]] = []
    cv = result.get("cv") or {}
    for key in ("headline", "summary"):
        if cv.get(key):
            segs.append((f"cv.{key}", str(cv[key])))
    hl = cv.get("highlight") or {}
    if hl.get("text"):
        segs.append(("cv.highlight", f"{hl.get('label', '')}. {hl['text']}"))
    for i, s in enumerate(cv.get("skills") or []):
        segs.append((f"cv.skills[{i}]", f"{s.get('label', '')}: {s.get('text', '')}"))
    for i, e in enumerate(cv.get("experience") or []):
        for j, b in enumerate(e.get("bullets") or []):
            segs.append((f"cv.experience[{i}].bullet[{j}]", str(b)))
    for i, e in enumerate(cv.get("earlier") or []):
        if e.get("line"):
            segs.append((f"cv.earlier[{i}]", str(e["line"])))
    letter = result.get("letter") or {}
    for j, p in enumerate(letter.get("paragraphs") or []):
        segs.append((f"letter.paragraph[{j}]", str(p)))
    return segs


def verify(result: dict, profile: dict, offer_text: str = "", today: dt.date | None = None) -> list[str]:
    today = today or dt.date.today()
    problems: list[str] = []
    text_of_profile = claim_text(profile)
    low_profile = text_of_profile.lower()
    prof_nums = _numbers(text_of_profile)
    offer_nums = _numbers(offer_text or "")
    years = total_years(profile, today)
    allowed_years = {str(int(years)), str(int(years) + 1)}
    not_exp = [str(x).strip() for x in (profile.get("not_experienced") or []) if str(x).strip()]

    for where, text in collect_segments(result):
        for sentence in _sentences(text):
            # CV text is always the candidate speaking, even without "I".
            first_person = where.startswith("cv.") or bool(FIRST_PERSON.search(sentence))
            # 1. numbers
            for m in NUM_RE.finditer(sentence):
                n = _norm_number(m.group(0))
                if n in prof_nums or n in allowed_years:
                    continue
                if n in offer_nums and not first_person:
                    continue  # quoting the employer's own figures
                problems.append(f"{where}: the number '{m.group(0)}' is not in your profile")
            # 2. years of experience
            for m in _YEARS_RE.finditer(sentence):
                raw = m.group(1).lower()
                claimed = int(raw) if raw.isdigit() else _WORD_NUMBERS.get(raw)
                if claimed is None:
                    continue
                if str(claimed) in prof_nums:
                    continue
                if first_person and claimed > years + 0.5:
                    problems.append(
                        f"{where}: claims {claimed} years but the profile supports about {years:g}"
                    )
            # 3. tools not in the profile
            for tool in KNOWN_TOOLS:
                m = _tool_pattern(tool).search(sentence)
                if m and tool.lower() not in low_profile and not _negated(sentence, m.start()):
                    problems.append(f"{where}: mentions '{tool}', which is not in your profile")
            # 4. explicit gaps
            for gap in not_exp:
                m = re.search(r"(?<![\w])" + re.escape(gap) + r"(?![\w])", sentence, re.I)
                if m and not _negated(sentence, m.start()):
                    problems.append(f"{where}: claims '{gap}', which you listed as not experienced")
    # de-duplicate, keep order
    seen: set[str] = set()
    out = []
    for p in problems:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out


def summarize(problems: Iterable[str]) -> str:
    items = list(problems)
    if not items:
        return "No unsupported claims found."
    return "\n".join(f"- {p}" for p in items)
