"""resume-tailor: honest, per-offer CVs and cover letters from one master profile."""

__version__ = "0.1.0"
